#Set-ExecutionPolicy Unrestricted -Force
echo copy_over_start_unzip

7z x  "D:\SoftWare-master\apache-maven-3.6.0-bin.zip" -o"D:\Tools\" * -y

echo set_eviriment_path

$SystemPath=[environment]::GetEnvironmentVariable("Path","Machine")
$SystemPath
$SystemPath+="D:\Tools\apache-maven-3.6.0\bin;"
#$env:Path

#change environment with reg

#set regV=HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment

#reg add "%regV%" /v "Path" /t REG_EXPAND_SZ /d "%Path%" /f

#change environment with [environment]::SetEnvironmentvariable

[environment]::SetEnvironmentvariable("Path", "$SystemPath","Machine")

