echo setidentify

$secpasswd = ConvertTo-SecureString "LUOyuanhang)(*15" -AsPlainText -Force
$mycreds = New-Object System.Management.Automation.PSCredential ("qq729943146", $secpasswd)
echo connect
#Enter-PSSession 52.231.65.16 -Credential $mycreds
$session = new-pssession 52.231.64.45 -Credential $mycreds
echo connect-over
echo start
echo "install OpenSSH"
#Invoke-Command -Session $session -FilePath "D:\powershell-cmd\TestEnvirmentSetUpCmd_fix.ps1"
#echo "transport file"
#scp D:\Java.rar qq729943146@52.231.64.45:D:\SoftWare-master\Java.rar
echo "install jenkins and jdk"
#Invoke-Command -Session $session -FilePath "D:\powershell-cmd\TestEnvirmentSetUpCmd2_fix.ps1"
#echo "transport file"
#scp "D:\SoftWare-master\sonarqube-7.5.zip" qq729943146@52.231.64.45:"D:\SoftWare-master\sonarqube-7.5.zip"
#echo "install SonarQube"
#Invoke-Command -Session $session -FilePath "D:\powershell-cmd\TestEnvirmentSetUpCmd3.ps1"
echo "transport file"
scp "D:\SoftWare-master\apache-maven-3.6.0-bin.zip" qq729943146@52.231.64.45:"D:\SoftWare-master\apache-maven-3.6.0-bin.zip"
echo "install maven"
Invoke-Command -Session $session -FilePath "D:\powershell-cmd\TestEnvirmentSetUpCmd5.ps1"
#echo "install visdio studio"
#Invoke-Command -Session $session -FilePath "D:\powershell-cmd\TestEnvirmentSetUpCmd4.ps1"
#echo "open iis"
#Invoke-Command -Session $session -FilePath "D:\powershell-cmd\setupIIS.ps1"

echo over
