7z x  "D:\SoftWare-master\Java.7z" -o"$env:ProgramFiles" * -y
Start-Process "D:\Tools\apache-tomcat-8.5.35\bin\startup.bat" -WindowStyle Hidden