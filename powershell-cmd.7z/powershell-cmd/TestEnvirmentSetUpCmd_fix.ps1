Xcopy "D:\SoftWare-master\authorized_keys" "C:\Users\qq729943146\.ssh\authorized_keys.*" /y
Xcopy "D:\SoftWare-master\ssh_config" "$env:ProgramData\ssh\ssh_config.*" /y
