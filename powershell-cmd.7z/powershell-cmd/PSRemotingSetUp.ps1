Enable-PSRemoting
Set-Item wsman:\localhost\Client\Trustedhosts *